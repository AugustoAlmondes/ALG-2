#include <stdio.h>

int main(){

int numero;
int a = 0;
int num = 0;

for (int i = 0; i < 5; i++){

    scanf("%i",&numero);

    if(numero < 0){
        printf ("%i",num);
        return 0;
    } else {

    num = numero + num;

}
i = 0;
}
}
