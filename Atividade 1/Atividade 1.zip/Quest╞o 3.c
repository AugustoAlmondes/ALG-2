#include <stdio.h>

int main(){

char destino;
int viagem;

scanf("%c",&destino);
scanf("%i",&viagem);

    if (viagem == 0){

    if (destino == 'a'){
        printf("\nR$ 500,00");
            }
    if (destino == 'b'){
        printf("\nR$ 350,00");
            }
    if (destino == 'c'){
        printf("\nR$ 350,00");
            }
    if (destino == 'd'){
        printf("\nR$ 300,00");
            }
} else

        if (viagem == 1){

    if (destino == 'a'){
        printf("\nR$ 900,00");
            }
    if (destino == 'b'){
        printf("\nR$ 650,00");
            }
    if (destino == 'c'){
        printf("\nR$ 600,00");
            }
    if (destino == 'd'){
        printf("\nR$ 550,00");
            }

}
}


