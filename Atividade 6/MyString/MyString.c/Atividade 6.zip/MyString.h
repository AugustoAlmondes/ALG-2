#ifndef MYSTRING_H_INCLUDED
#define MYSTRING_H_INCLUDED


char *mystrcpy(char *s1, const char *s2);
char *mystrncpy(char *s1, const char *s2, size_t n);
char *mystrcat(char *s1, const char *s2);
char *mystrncat(char *s1, const char *s2, size_t n);
int *mystrcmp(const char *s1, const char *s2);
int *mystrncmp(const char *s1, const char *s2, size_t n);
int *mystrncmp(const char *s1, const char *s2, size_t n);
#endif // MYSTRING_H_INCLUDED
