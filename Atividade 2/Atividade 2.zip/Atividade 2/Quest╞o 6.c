#include <stdio.h>
#define m 3
#define n 2
#define p 2

int main()
{

    int A[m][n];
    int B[n][p];
    int C[m][p];

    for(int i = 0; i < 3; i++)
    {
        for(int j = 0; j <2; j++)
        {
            C[i][j] = 0;
            scanf("%i", &A[i][j]);

        }
    }
    for(int i = 0; i < 2; i++)
    {
        for(int j = 0; j <2; j++)
        {

            scanf("%i", &B[i][j]);

        }
    }
for (int i=0; i<m; i++ ){

     for ( int j=0; j<p; j++ ){

          for (int  k=0; k<n; k++ ){

            C[i][j] += A[i][k] * B[k][j];

        }
    }
}

     for ( int i=0; i<m; i++ ){

          for (int  j=0; j<n; j++ ){

            printf("%i ", C[i][j]);

        }
        printf("\n");
    }
}



